* * * * * * * * * *
*       emu       *
* * * * * * * * * *

8086 assembler and
 microprocessor emulator 


* * * * * * * * * *
*   the purpose   *
* * * * * * * * * *

emu is for those
who just begin to study
computer arhitecture
and assembly language
programming.

emu emulates hardware,
such as screen, memory and
input/output devices.

emu combines an advanced
source editor, assembler,
emulator and debugger.


* * * * * * * * * *
*     contact     *
* * * * * * * * * *

if you have any questions,
or suggestions or just want
to talk feel free to drop
me a line:

yurim@nana10.co.il

http://button4.com


