

ports corresspond to bytes
in this file:
emu8086.io


for location see
  emu8086.ini

